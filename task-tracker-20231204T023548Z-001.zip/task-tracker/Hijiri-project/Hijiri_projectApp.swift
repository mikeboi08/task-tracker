//
//  Hijiri_projectApp.swift
//  Hijiri-project
//
//  Created by Micah Howard on 11/13/23.
//

import SwiftUI

@main
struct Hijiri_projectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
